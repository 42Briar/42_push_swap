/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   utils.c                                            :+:    :+:            */
/*                                                     +:+                    */
/*   By: lde-la-h <lde-la-h@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2021/11/04 13:07:55 by lde-la-h      #+#    #+#                 */
/*   Updated: 2021/11/10 14:27:42 by lde-la-h      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

static t_bool	parse_line(const char *str)
{
	t_size	i;
	t_i32	neg;

	i = 0;
	neg = 1;
	while (ft_isspace(str[i]))
		i++;
	if (str[i] == '-' || str[i] == '+')
	{
		if (str[i] == '-')
			neg = -1;
		i++;
	}
	while (str[i])
	{
		if (ft_isdigit(str[i]))
			i++;
		else
			return (false);
	}
	return (true);
}

t_bool	is_sorted(t_stack *stack)
{
	t_list	*c;

	c = stack->data;
	while (c->next)
	{
		if (((t_val *)c->next->content)->num < ((t_val *)c->content)->num)
			return (false);
		c = c->next;
	}
	return (true);
}

t_val	*get_at(t_stack *stack, t_i32 index)
{
	t_i32	i;
	t_list	*c;

	i = 0;
	c = stack->data;
	if (index > stack->size)
		return ((t_val *)ft_lstlast(stack->data)->content);
	while (i < index && c)
	{
		c = c->next;
		i++;
	}
	return ((t_val *)c->content);
}

t_val	*insert_arg(char *n)
{
	t_val	*out;

	out = malloc(sizeof(t_val));
	if (!out || !parse_line(n))
		exit_error(NULL, NULL);
	out->num = ft_atoi(n);
	out->radix_index = -1;
	return (out);
}
